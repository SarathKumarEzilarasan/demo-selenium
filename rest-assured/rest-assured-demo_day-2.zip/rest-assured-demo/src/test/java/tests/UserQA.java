package tests;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.restassured.response.Response;
import models.User;
import org.testng.Assert;
import org.testng.annotations.Test;

public class UserQA extends BaseTest {
    int userId;
    ObjectMapper objectMapper = new ObjectMapper();

    @Test
    public void getUsers() {
        Response response = get("users");
    }

    @Test
    public void createUser() throws JsonProcessingException {
        String email = "john" + System.currentTimeMillis() + "@gmail.com";
        User user = new User();
        user.setName("john");
        user.setEmail(email);
        user.setGender("male");
        user.setStatus("active");
        Response response = post("users", user);
        User responseBody = objectMapper.readValue(response.body().asString(), User.class);
        Assert.assertEquals(user.getName(), responseBody.getName());
        Assert.assertEquals(user.getEmail(), responseBody.getEmail());
        Assert.assertEquals(user.getGender(), responseBody.getGender());
        Assert.assertEquals(user.getStatus(), responseBody.getStatus());
        userId = responseBody.getId();
    }

    @Test
    public void updateUser() throws JsonProcessingException {
        User responseBody = createUserFunc();
        User updateUser = new User();
        updateUser.setName("john");
        updateUser.setEmail(responseBody.getEmail());
        updateUser.setGender("male");
        updateUser.setStatus("inactive");
        Response updateResponse = patch("users/" + responseBody.getId(), updateUser);
        User updateResponseBody = objectMapper.readValue(updateResponse.body().asString(), User.class);
        Assert.assertEquals(updateResponseBody.getStatus(), updateUser.getStatus());
    }

    @Test
    public void deleteUser() throws JsonProcessingException {
        User responseBody = createUserFunc();
        Response response = delete("users/" + responseBody.getId());
    }

    public User createUserFunc() throws JsonProcessingException {
        String email = "john" + System.currentTimeMillis() + "@gmail.com";
        User createUser = new User();
        createUser.setName("john");
        createUser.setEmail(email);
        createUser.setGender("male");
        createUser.setStatus("active");
        Response createResponse = post("users", createUser);
        User responseBody = objectMapper.readValue(createResponse.body().asString(), User.class);
        return responseBody;
    }
}
