package tests;

import io.restassured.RestAssured;
import io.restassured.builder.RequestSpecBuilder;
import io.restassured.builder.ResponseSpecBuilder;
import io.restassured.filter.log.LogDetail;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;
import io.restassured.specification.ResponseSpecification;
import models.User;
import org.testng.annotations.BeforeTest;

import static io.restassured.RestAssured.given;

public class BaseTest {
    RequestSpecification requestSpecification;
    ResponseSpecification responseSpecification;

    @BeforeTest
    public void setUp() {
        RestAssured.baseURI = "https://gorest.co.in/public/v2/";
        requestSpecification = new RequestSpecBuilder()
                .addHeader("Authorization"
                        , "Bearer ae11c5df458b41fbb06cc4bda6881b53f920f3f47cc38cf18251b28fa5b56e90")
                .addHeader("Accept", "application/json")
                .addHeader("Content-Type", "application/json")
                .log(LogDetail.ALL).build();
        responseSpecification = new ResponseSpecBuilder().log(LogDetail.ALL).build();
    }

    public Response get(String endPoint) {
        return given(requestSpecification)
                .when().get(endPoint)
                .then().spec(responseSpecification).statusCode(200).extract().response();
    }

    public Response post(String endPoint, Object body) {
        return given(requestSpecification)
                .body(body)
                .when().post(endPoint)
                .then().spec(responseSpecification).statusCode(201).extract().response();
    }

    public Response patch(String endPoint, Object body) {
        return given(requestSpecification)
                .body(body)
                .when().patch(endPoint)
                .then().spec(responseSpecification).statusCode(200).extract().response();
    }

    public Response delete(String endPoint) {
        return given(requestSpecification)
                .when().delete(endPoint)
                .then().spec(responseSpecification).statusCode(204).extract().response();
    }


}
