package tests;

import io.restassured.response.Response;
import models.User;
import org.testng.annotations.Test;

public class UserQA extends BaseTest {

    @Test
    public void getUsers() {
        Response response = get("users");
        System.out.println(response.body().asString());
    }

    @Test
    public void createUser() {
        User user = new User();
        user.setName("john");
        user.setEmail("john@gamil.com");
        user.setGender("male");
        user.setStatus("active");
        Response response = post("users", user);
    }

    @Test
    public void updateUser() {
        User user = new User();
        user.setName("john");
        user.setEmail("john@gamil.com");
        user.setGender("male");
        user.setStatus("inactive");
        Response response = patch("users", user);
    }

    @Test
    public void deleteUser() {
        Response response = delete("users" + "");
    }


}
