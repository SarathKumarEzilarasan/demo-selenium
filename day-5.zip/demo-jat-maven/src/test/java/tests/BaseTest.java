package tests;

import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.BeforeClass;
import pages.*;
import utils.QaProps;
import utils.TestDataReader;

public class BaseTest {

    ChromeDriver driver;
    ListPage listPage;
    TextBoxPage textBoxPage;

    MessagePage messagePage;
    IframePage iframePage;
    AlertPage alertPage;
    DragPage dragPage;

//OOPS -> Inheritance

    String url;

    @BeforeClass
    public void setUp() {
        driver = new ChromeDriver();
        listPage = new ListPage(driver);
        textBoxPage = new TextBoxPage(driver);
        messagePage = new MessagePage(driver);
        iframePage = new IframePage(driver);
        alertPage = new AlertPage(driver);
        dragPage = new DragPage(driver);
        driver.get("https://www.leafground.com/input.xhtml");
        driver.manage().window().maximize();
        QaProps.init();
        TestDataReader.init();
        url = QaProps.getProperty("url");
//        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
    }

    // @AfterClass
    public void tearDown() {
        driver.quit();
    }
}
