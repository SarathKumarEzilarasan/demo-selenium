package utils;

public class UrlConstants {
    public static final String MESSAGE_URL = "messages.xhtml";
    public static final String ALERT_URL = "alert.xhtml";
    public static final String IFRAME_URL = "frame.xhtml";
    public static final String WINDROW_URL = "window.xhtml";
    public static final String DRAG_URL = "drag.xhtml";
}
