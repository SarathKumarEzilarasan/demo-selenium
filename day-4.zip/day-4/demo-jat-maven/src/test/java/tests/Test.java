package tests;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Test {

    public static void main(String[] args) {
        ChromeDriver chromeDriver = new ChromeDriver();
        chromeDriver.get("https://www.snapdeal.com/");
        // locators -> id, xpath ,
        //APjFqb
//        By by = By.id("APjFqb");
//        WebElement element = chromeDriver.findElement(by);
//        element.sendKeys("mobiles");
//        element.sendKeys(Keys.ENTER);

        chromeDriver.findElement(By.id("userName")).sendKeys("test");
    }
}
