package runners;

public class Demo {

    static int x = 100;
    int y = 100;


    public static void main(String[] args) {
        Demo d1 = new Demo();
        Demo.x = 2000;
        Demo d2 = new Demo();
        Demo.x = 3000;
        System.out.println(Demo.x);
        System.out.println(d2.y);
    }
}
