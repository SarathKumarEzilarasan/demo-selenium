package utils;

import org.openqa.selenium.WebDriver;
import pages.SignupPage;

public class TestContext {
    public WebDriver driver;
    public SignupPage signupPage;
}
