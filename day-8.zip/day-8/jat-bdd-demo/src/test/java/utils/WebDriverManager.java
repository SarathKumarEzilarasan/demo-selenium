package utils;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

public class WebDriverManager {
    public TestContext testContext;

    public WebDriverManager(TestContext testContext) {
        this.testContext = testContext;
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--headless");
        testContext.driver = new ChromeDriver();
    }

}
