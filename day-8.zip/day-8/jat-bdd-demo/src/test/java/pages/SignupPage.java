package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import utils.TestContext;

public class SignupPage {

    private WebDriver driver;

    public SignupPage(TestContext testContext) {
        this.driver = testContext.driver;
        PageFactory.initElements(driver, this);
    }

    @FindBy(name = "first_name")
    WebElement firstNameEle;
    @FindBy(name = "last_name")
    WebElement lastNameEle;
    @FindBy(name = "business_name")
    WebElement businessNameEle;
    @FindBy(name = "email")
    WebElement emailEle;
    @FindBy(id = "number")
    WebElement numberInputBoxEle;
    @FindBy(id = "numb1")
    WebElement num1Ele;
    @FindBy(id = "numb2")
    WebElement num2Ele;
    @FindBy(id = "demo")
    WebElement submitBtn;

    public void signup() {
        int x = Integer.parseInt(num1Ele.getText());
        int y = Integer.parseInt(num2Ele.getText());
        int sum = x + y;
        numberInputBoxEle.sendKeys(sum + "");
        submitBtn.click();
    }

    public void fillNames(String firstName, String lastName) {
        firstNameEle.sendKeys(firstName);
        lastNameEle.sendKeys(lastName);
    }

    public void fillEmailBusinessName(String email, String businessName) {
        emailEle.sendKeys(email);
        businessNameEle.sendKeys(businessName);
    }

}










