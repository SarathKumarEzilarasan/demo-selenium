package stepdefs;

import io.cucumber.java.After;
import io.cucumber.java.AfterAll;
import io.cucumber.java.Before;
import io.cucumber.java.BeforeAll;
import org.openqa.selenium.WebDriver;
import pages.SignupPage;
import utils.TestContext;
import utils.WebDriverManager;

public class Hooks {

    private WebDriver driver;
    private WebDriverManager webDriverManager;

    public Hooks(TestContext testContext) {
        this.webDriverManager = new WebDriverManager(testContext);
        this.driver = webDriverManager.testContext.driver;
        testContext.signupPage = new SignupPage(testContext);
    }

    @BeforeAll
    public static void setUp() {
        System.out.println("before all");
    }

    @Before
    public void before() {
        this.driver.manage().window().maximize();
    }

    @After
    public void after() {
        this.driver.quit();
    }

    @AfterAll
    public static void tearDown() {
        System.out.println("after all");
    }

}
