package stepdefs;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.WebDriver;
import pages.SignupPage;
import utils.TestContext;

public class SignupStepDefs {
    private WebDriver driver;
    private SignupPage signupPage;

    public SignupStepDefs(TestContext testContext) {
        this.driver = testContext.driver;
        this.signupPage = testContext.signupPage;
    }

    @Given("Navigate to the signup page")
    public void navigateToTheSignupPage() {
        driver.get("https://phptravels.com/demo/");
    }

    @When("the user enter valid values in the input form")
    public void theUserEnterValidValuesInTheInputForm() {
//        signupPage.signup("user",
//                "user",
//                "user@gmail.com",
//                "selenium demo");
    }

    @Then("the thank you message is displayed")
    public void theThankYouMessageIsDisplayed() {
        //assertion
    }

    @When("the user enters {string} and {string} as firstname and lastname")
    public void theUserEntersAndAsFirstnameAndLastname(String firstName, String lastName) {
        signupPage.fillNames(firstName, lastName);
    }

    @And("the user enters {string} as businessname and {string} as email")
    public void theUserEntersAsBusinessnameAndAsEmail(String businessName, String email) {
        signupPage.fillEmailBusinessName(email, businessName);
        signupPage.signup();
    }
}
