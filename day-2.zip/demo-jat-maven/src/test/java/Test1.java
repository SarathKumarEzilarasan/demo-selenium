public class Test1<T extends Number> {

    public T i;

    public Test1(T i) {
        this.i = i;
    }


    public T getI() {
        return i;
    }
}
