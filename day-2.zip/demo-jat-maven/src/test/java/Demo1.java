public class Demo1 {
    public static void main(String[] args) {
        String s1 = "hello world"; // 1GB


        System.out.println(s1.toUpperCase());
        System.out.println(s1);
    }
}


// JVM -> Heap , Stack