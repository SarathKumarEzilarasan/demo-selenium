import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.util.List;

public class Demo {

    ChromeDriver driver;

    @BeforeClass
    public void setUp() {
        driver = new ChromeDriver();
        driver.get("https://www.leafground.com/input.xhtml");
        driver.manage().window().maximize();
    }


    @Test
    public void textBoxTest() {
        driver.findElement(By.xpath("//input[@name='j_idt88:name']"))
                .sendKeys("test user");
        driver.findElement(By.xpath("//input[@name='j_idt88:name']"))
                .sendKeys("test user");
        driver.findElement(By.xpath("//input[@name='j_idt88:j_idt91']"))
                .sendKeys(" India");
        boolean flag = driver.findElement(By.id("j_idt88:j_idt93")).isEnabled();
        Assert.assertFalse(flag);
        driver.findElement(By.id("j_idt88:j_idt95")).clear();
        String value = driver.findElement(By.xpath("//input[@id='j_idt88:j_idt97']"))
                .getAttribute("value");
        Assert.assertEquals(value, "My learning is superb so far.");
    }

    @Test
    public void buttonTest() throws InterruptedException {
        driver.get("https://www.leafground.com/button.xhtml");
        driver.findElement(By.id("j_idt88:j_idt90")).click();
        String url = driver.getCurrentUrl();
        Assert.assertEquals(url, "https://www.leafground.com/dashboard.xhtml");
        driver.get("https://www.leafground.com/button.xhtml");

        int x = driver.findElement(By.xpath("//button[@id='j_idt88:j_idt94']")).getLocation().getX();
        int y = driver.findElement(By.xpath("//button[@id='j_idt88:j_idt94']")).getLocation().getY();

        Assert.assertEquals(x, 81);
        Assert.assertEquals(y, 400);

        String actualColor = driver.findElement(By.xpath("//button[@id='j_idt88:j_idt96']"))
                .getCssValue("background");
        boolean color = actualColor.contains("rgb(96, 125, 139)");
        Assert.assertTrue(color);

//        driver.findElement(By.id("j_idt88:j_idt98")).getSize().getHeight();
//        driver.findElement(By.id("j_idt88:j_idt98")).getSize().getWidth();

        driver.findElement(By.xpath("//button[@name='j_idt88:j_idt102:imageBtn']"))
                .click();
        Thread.sleep(2000);
        driver.findElement(By.xpath("//button[@name='j_idt88:j_idt102:imageBtn']"))
                .click();
        driver.findElement(By.id("j_idt88:j_idt107")).click();
        List<WebElement> list =
                driver.findElements(By.xpath("//button[contains(@class,\"rounded-button\")]"));
        Assert.assertEquals(list.size(), 4);

    }


    @AfterClass
    public void tearDown() {
        driver.quit();
    }

}
