public class Test {
    public static void main(String[] args) {
        String s = "1-20-21";
        String[] arr = s.split("-");
        System.out.println(arr[0]);
        System.out.println(arr[1]);
    }
}
